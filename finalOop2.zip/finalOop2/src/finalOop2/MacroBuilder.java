package finalOop2;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.text.DecimalFormat;
public class MacroBuilder extends Application {
    private static DecimalFormat df = new DecimalFormat("0");
    public static void main(String[] args) {
        launch(args);
        
    }
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("MacroBuilder");
        TextArea feedTimesArea = new TextArea();
        feedTimesArea.setEditable(false);
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        Label nameLabel = new Label("Name:");
        TextField nameField = new TextField();
        Label weightLabel = new Label("Weight (lbs):");
        TextField weightField = new TextField();
        Label heightLabel = new Label("Height (inches):");
        TextField heightField = new TextField();
        Label ageLabel = new Label("Age (years):");
        TextField ageField = new TextField();
        Label genderLabel = new Label("Gender (Male/Female):");
        TextField genderField = new TextField();
        Label goalLabel = new Label("Goal (1-lose, 2-gain, 3-maintain):");
        TextField goalField = new TextField();
        Button calculateButton = new Button("Calculate");
          
        grid.addRow(0, nameLabel, nameField);
        grid.addRow(1, weightLabel, weightField);
        grid.addRow(2, heightLabel, heightField);
        grid.addRow(3, ageLabel, ageField);
        grid.addRow(4, genderLabel, genderField);
        grid.addRow(5, goalLabel, goalField);
        grid.addRow(6, calculateButton);
        grid.addRow(7, feedTimesArea);
        Scene scene = new Scene(grid, 700, 600);
        primaryStage.setScene(scene);
        primaryStage.show();
       
        calculateButton.setOnAction(e -> handleCalculate(nameField.getText(), weightField.getText(), heightField.getText(),
                ageField.getText(), genderField.getText(), goalField.getText(), feedTimesArea));
		
    }
    public static String[] feedtimes(MacroUser userObj, double goalprotein, double goalfat, double goalcarb) {
    	// create array for hours of the day to eat
		String[] feedtimes = new String[6];
		final double tempProtein = goalprotein;
		final double tempCarbs = goalcarb;
		final double tempFat = goalfat;
		// calculate macros per meal and display
		goalprotein = (goalprotein * .14) / 100 * 100;
		goalcarb = (goalcarb * .25);
		goalfat = (goalfat * .2);
		feedtimes[0] = "Between 7 A.M. and 9 A.M. eat:\n" + df.format(goalprotein) + " grams of protein\n"
				+ df.format(goalcarb) + " grams of carbs\n" + df.format(goalfat) + " grams of fat\n "
						+ "You have the option of: " + goalprotein;
		goalprotein = tempProtein;
		goalcarb = tempCarbs;
		goalfat = tempFat;
		goalprotein = (goalprotein * .15);
		goalcarb = (goalcarb * .25);
		goalfat = (goalfat * .2);
		feedtimes[1] = "Between 9 A.M. and 11 A.M. eat:\n" + df.format(goalprotein) + " grams of protein\n"
				+ df.format(goalcarb) + " grams of carbs\n" + df.format(goalfat) + " grams of fat\n";
		goalprotein = tempProtein;
		goalcarb = tempCarbs;
		goalfat = tempFat;
		goalprotein = (goalprotein * .16);
		goalcarb = (goalcarb * .25);
		goalfat = (goalfat * .2);
		feedtimes[2] = "Between 11 A.M. and 1 P.M. eat:\n" + df.format(goalprotein) + " grams of protein\n"
				+ df.format(goalcarb) + " grams of carbs\n" + df.format(goalfat) + " grams of fat\n";
		goalprotein = tempProtein;
		goalcarb = tempCarbs;
		goalfat = tempFat;
		goalprotein = (goalprotein * .17);
		goalcarb = (goalcarb * .15);
		goalfat = (goalfat * .2);
		feedtimes[3] = "Between 1 P.M. and 3 P.M. eat:\n" + df.format(goalprotein) + "grams of protein\n"
				+ df.format(goalcarb) + " grams of carbs\n" + df.format(goalfat) + " grams of fat\n";
		goalprotein = tempProtein;
		goalcarb = tempCarbs;
		goalfat = tempFat;
		goalprotein = (goalprotein * .18);
		goalcarb = (goalcarb * .1);
		goalfat = (goalfat * .1);
		feedtimes[4] = "Between 3 P.M. and 5 P.M. eat:\n" + df.format(goalprotein) + " grams of protein\n"
				+ df.format(goalcarb) + " grams of carbs\n" + df.format(goalfat) + " grams of fat\n";
		goalprotein = tempProtein;
		goalcarb = tempCarbs;
		goalfat = tempFat;
		goalprotein = (goalprotein * .2);
		goalcarb = (goalcarb * .1);
		goalfat = (goalfat * .1);
		feedtimes[5] = "Between 5 P.M. and 7 P.M. eat:\n" + df.format(goalprotein) + " grams of protein\n"
				+ df.format(goalcarb) + " grams of carbs\n" + df.format(goalfat) + " grams of fat\n";
		return feedtimes;
    }
    private void handleCalculate(String name, String weight, String height, String age, String gender, String goal, TextArea feedTimesArea) {    	
    	MacroUser userObj = new MacroUser();
	userObj.setUser(name);
	userObj.setGender(gender);
    
	userObj.setWeight(Double.parseDouble (weight));
	userObj.setHeight(Double.parseDouble (height));
	userObj.setAge(Integer.parseInt(age));
	userObj.setGoal(Integer.parseInt(goal));
	
	userObj.setBMR();
	System.out.println(userObj.getBMR());
	userObj.setTdee();
	userObj.setGoalCal();
	userObj.setGoalProtein();
	userObj.setGoalCarb();
	userObj.setGoalFat();
	StringBuilder feedTimesText = new StringBuilder();
	String[] feedTimes = feedtimes (userObj,
			userObj.getgoalprotein(),
			userObj.getgoalfat(),
			userObj.getgoalcarb());
	for (String feedTime : feedTimes) {
		feedTimesText.append(feedTime).append("\n");
		System.out.print(feedTimes);
	}
	feedTimesArea.setText(feedTimesText.toString());
	
			
    }
public class MacroUser {
	private String user = "";
	private String gender = "";
	private double weightField = 0;
	private double height = 0;
	private int age = 0;
	private int goal = 0;
	private double bmr = 0;
	private double tdee = 0;
	private double goalcal = 0;
	private double goalprotein = 0;
	private double goalcarb = 0;
	private double goalfat = 0;
	MacroUser() {
	}
	MacroUser( String gender, double weight, double height, int age, int goal) {
		this.gender = gender;
		this. weightField = weight;
		this.height = height;
		this.age = age;
		this.goal = goal;
	}
//get&set input of user and calculate goal macros
	String getuser() {
		return this.user;
	}
	String getgender() {
		return this.gender;
	}
	double getweight() {
		return this. weightField;
	}
	double getheight() {
		return this.height;
	}
	double getage() {
		return this.age;
	}
	double getBMR() {
		return this.bmr;
	}
	double getTdee() {
		return this.tdee;
	}
	double getgoalprotein() {
		return this.goalprotein;
	}
	double getgoalcal() {
		return this.goalcal;
	}
	double getgoalcarb() {
		return this.goalcarb;
	}
	double getgoalfat() {
		return this.goalfat;
	}
	int getgoal() {
		return this.goal;
	}
	void setUser(String user) {
		this.user = user;
	}
	void setGender(String gender) {
		this.gender = gender;
	}
	void setWeight(double weight) {
		this. weightField = weight;
	}
	void setHeight(double height) {
		this.height = height;
	}
	void setAge(int age) {
		this.age = age;
	}
	void setGoal(int goal) {
		this.goal = goal;
	}
	void setBMR() {
		if (gender.equalsIgnoreCase("male")) {
			this.bmr = 655 + (4.35 *  weightField) + (4.7 * height) - (4.7 * age);
		} else if (gender.equalsIgnoreCase("female")) {
			this.bmr = 66 + (6.23 *  weightField) + (12.7 * height) - (6.8 * age);
		}
	}
	void setTdee() {
		this.tdee = this.bmr * 1.2;
	}
	void setGoalCal() {
		if (this.goal == 1) {
			this.goalcal = this.tdee * 0.8;
		} else if (goal == 2) {
			this.goalcal = this.tdee * 1.4;
		} else {
			this.goalcal = this.tdee;
		}
	}
	void setGoalProtein() {
		if (this.goal == 1) {
			this.goalprotein = (goalcal * 0.4) / 4;
		} else if (this.goal == 2) {
			this.goalprotein = (goalcal * 0.5) / 4;
		} else {
			this.goalprotein = (goalcal * 0.4) / 4;
		}
	}
	void setGoalCarb() {
		if (this.goal == 1) {
			this.goalcarb = (goalcal * 0.3) / 4;
		} else if (this.goal == 2) {
			this.goalcarb = (goalcal * 0.5) / 4;
		} else {
			this.goalcarb = (goalcal * 0.2) / 4;
		}
	}
	void setGoalFat() {
		switch (this.goal) {
		case 1:
			this.goalfat = (this.goalcal * 0.1) / 9;
		case 2:
			this.goalfat = (this.goalcal * 0.4) / 9;
		default:
			this.goalfat = (this.goalcal * 0.4) / 9;
		}
}}}